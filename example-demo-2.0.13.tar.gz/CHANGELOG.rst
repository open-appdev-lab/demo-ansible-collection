==================
Demo Release Notes
==================

.. contents:: Topics

v2.0.13
=======

Bugfixes
--------

- stage all changes during build (#37)

v2.0.9
======

Bugfixes
--------

- handle perf type in changelog (#32)

v2.0.8
======

Bugfixes
--------

- add file test (#31)

Known Issues
------------

- fix double triggering

v2.0.7
======

Bugfixes
--------

- update workflows (#28)

v2.0.6
======

Bugfixes
--------

- update commit message

v2.0.5
======

Release Summary
---------------

revise documentation with batch PRs merge group

Bugfixes
--------

- add adhoc changes
- set name in playbook (#26)
- set the name (#27)
- update output message in playbook (#22)

Known Issues
------------

- add adhoc changes
- add check push to main
- update pipelines (#19)

Documentation Changes
---------------------

- add adhoc changes
- add badge to README (#20)
- add contribution documentation (#21)
- add release_summary (#23)

v2.0.4
======

Bugfixes
--------

- revise collection metadata

Known Issues
------------

- Update README.md
- enforce environment approval
- fix concurrency group name
- remove check for environment

Documentation Changes
---------------------

- revise collection metadata and documentation

v2.0.3
======

v2.0.2
======

v2.0.1
======

v2.0.0
======

v1.14.8
=======

v1.14.7
=======

v1.14.6
=======

v1.14.5
=======

v1.14.4
=======

v1.14.3
=======

v1.14.2
=======

v1.14.1
=======

v1.14.0
=======

v1.13.0
=======

v1.12.0
=======

v1.11.2
=======

v1.11.1
=======

v1.11.0
=======

v1.10.0
=======

v1.9.5
======

v1.9.4
======

v1.9.3
======

v1.9.2
======

v1.9.1
======

v1.9.0
======

v1.8.1
======

v1.8.0
======

v1.7.0
======

v1.6.0
======

v1.5.0
======

v1.4.2
======

v1.4.1
======

v1.4.0
======

v1.3.5
======

v1.3.4
======

v1.3.3
======

v1.3.2
======

v1.3.1
======

v1.3.0
======

v1.1.3
======

