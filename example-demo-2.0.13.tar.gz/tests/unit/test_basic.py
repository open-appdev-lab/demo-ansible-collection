"""Unit tests for infra.openshift_virtualization_ops."""


def test_basic() -> None:
    """Dummy unit test that always passes.

    Raises:
        AssertionError: If the assertion fails.
    """
    assert bool(1) is True
