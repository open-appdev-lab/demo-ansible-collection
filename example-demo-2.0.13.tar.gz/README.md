# 📃 Collection overview

![GitHub Release](https://img.shields.io/github/v/release/open-appdev-lab/demo-ansible-collection?include_prereleases&style=flat-square)
[![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/open-appdev-lab/demo-ansible-collection/ci.yml?style=flat-square&label=release)](https://github.com/open-appdev-lab/demo-ansible-collection/actions)
[![Semantic Versioning](https://img.shields.io/badge/semver-2.0.0-blue?style=flat-square)](https://semver.org/)
[![License](https://img.shields.io/github/license/open-appdev-lab/demo-ansible-collection?style=flat-square)](LICENSE)
